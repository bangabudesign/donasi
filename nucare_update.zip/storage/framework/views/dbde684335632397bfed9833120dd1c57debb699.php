

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex justify-between">
    <div class="left">
        <h2 class="text-3xl font-bold leading-tight"><?php echo e($title); ?></h2>
        <p class="mt-0 text-gray-600"><?php echo e($subtitle); ?></p>
    </div>
    <div class="mt-auto">
        <a href="<?php echo e(route('admin.campaigns.create')); ?>" class="btn btn-success">Add New</a>
    </div>
</div>
<?php if(session('successMessage')): ?>
    <div class="alert alert-success">
        <?php echo e(session('successMessage')); ?>

    </div>
<?php endif; ?>
<div class="card card-body">
    <div class="-m-6 overflow-x-auto">
        <table class="table w-full whitespace-no-wrap">
            <thead>
                <tr class="text-left">
                    <th>Image</th>
                    <th>Title</th>
                    <th>Target</th>
                    <th>Finished at</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="w-20">
                            <img src="<?php echo e($campaign->thumbnail); ?>" alt="fatured_image" class="w-full rounded cursor-pointer hover:shadow">
                        </div>
                    </td>
                    <td><?php echo e(Helper::truncate($campaign->title,30,'...')); ?><br>
                        <p class="leading-tight text-gray-500"><?php echo e($campaign->code); ?></p>
                    </td>
                    <td>Rp<?php echo e($campaign->donation_target_formatted); ?></td>
                    <td><?php echo e($campaign->finished_at_formatted); ?></td>
                    <td><?php echo $campaign->status_formatted; ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.campaigns.edit', $campaign->id)); ?>" class="btn-text-info">Edit</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">No Data</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMER\Development\nucare\resources\views/admin/campaign/index.blade.php ENDPATH**/ ?>