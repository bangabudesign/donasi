

<?php $__env->startSection('content'); ?>
<!-- select payment -->
<div class="container max-w-md mx-auto px-4 pt-20 pb-4 min-h-screen bg-white">
    <?php if($donation->payment_status == 0): ?>
        <h4 class="font-semibold">Menunggu Pembayaran</h4>
        <p class="text-gray-600 mb-5">Segera lakukan pembayaran agar donasi dapat segera diproses</p>
        <hr class="mb-5">
        <h4 class="font-semibold text-center mb-4">Segera lakukan transfer dalam waktu</h4>
        <!-- count down -->
        <div class="text-center mb-5">
            <div class="flex space-x-2 font-light">
              <div class="w-1/3 bg-gray-200 rounded-md lg text-center py-4">
                <h4 id="hourText" class="text-lg leading-none font-bold text-gray-700">1</h4>
                <p class="text-sm leading-none">Jam</p>
              </div>
              <div class="w-1/3 bg-gray-200 rounded-md lg text-center py-4">
                <h4 id="minuteText" class="text-lg leading-none font-bold text-gray-700">31</h4>
                <p class="text-sm leading-none">Menit</p>
              </div>
              <div class="w-1/3 bg-gray-200 rounded-md lg text-center py-4">
                <h4 id="secondText" class="text-lg leading-none font-bold text-gray-700">10</h4>
                <p class="text-sm leading-none">Detik</p>
              </div>
            </div>
        </div>
        <!-- count down end -->
    <?php elseif($donation->payment_status == 2): ?>
        <h4 class="font-semibold">Menunggu Verifikasi</h4>
        <p class="text-gray-600 mb-5">Donasi anda sedang diverifikasi mohon tunggu sejenak</p>
        <hr class="mb-5">
        <h4 class="font-semibold text-center mb-4">Segera lakukan transfer dalam waktu</h4>
        <!-- count down -->
        <div class="text-center mb-5">
            <div class="flex space-x-2 font-light">
              <div class="w-1/3 bg-gray-200 rounded-md lg text-center py-4">
                <h4 id="hourText" class="text-lg leading-none font-bold text-gray-700">1</h4>
                <p class="text-sm leading-none">Jam</p>
              </div>
              <div class="w-1/3 bg-gray-200 rounded-md lg text-center py-4">
                <h4 id="minuteText" class="text-lg leading-none font-bold text-gray-700">31</h4>
                <p class="text-sm leading-none">Menit</p>
              </div>
              <div class="w-1/3 bg-gray-200 rounded-md lg text-center py-4">
                <h4 id="secondText" class="text-lg leading-none font-bold text-gray-700">10</h4>
                <p class="text-sm leading-none">Detik</p>
              </div>
            </div>
        </div>
    <?php elseif($donation->payment_status == 1): ?>
        <h4 class="font-semibold">Donasi Success</h4>
        <p class="text-gray-600 mb-5">Donasi telah berhasil diverifikasi, semoga anda mendapatkan pahala yang berlimpah</p>
    <?php endif; ?>
    <hr class="mb-5">
    <p class=""><?php echo e($donation->created_at_formatted); ?></p>
    <p class="mb-5">Nomor Invoice <b><?php echo e($donation->invoice); ?></b></p>
    <div class="mb-5">
        <label class="form-label">NOMINAL</label>
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <p class="text-2xl font-semibold">Rp<?php echo e($donation->amount_formatted); ?></p>
            </div>
            <a href="#" class="btn-sm" onclick="copyText(event, amount)">Salin</a>
            <input id="amount" value="<?php echo e($donation->amount); ?>" style="position: absolute; z-index:-1">
        </div>
    </div>
    <div class="mb-5">
        <label class="form-label">PENERIMA</label>
        <div class="flex items-center justify-between">
            <div class="flex items-center">
                <div class="rounded overflow-hidden">
                    <img src="<?php echo e($donation->payment_method->image_url); ?>" alt="<?php echo e($donation->payment_method->short_name); ?>">
                </div>
                <div class="ml-3">
                    <p class="text-sm uppercase font-semibold">A/N <?php echo e($donation->payment_method->detail_3); ?></p>
                    <p class="text-sm text-gray-600"><?php echo e($donation->payment_method->short_name); ?> <b><?php echo e($donation->payment_method->detail_2); ?></b></p>
                </div>
            </div>
            <a href="#" class="btn-sm" onclick="copyText(event, bankNumber)">Salin</a>
            <input id="bankNumber" value="<?php echo e($donation->payment_method->detail_2); ?>" style="position: absolute; z-index:-1">
        </div>
    </div>
    <hr class="mb-5">
    <?php if($donation->payment_status == 0): ?>
        <form action="<?php echo e(route('donation.confirm', $donation->invoice)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-4">
                <label for="payment_date" class="form-label uppercase">Tanggal Donasi</label>
                <input id="payment_date" name="payment_date" type="datetime-local" class="form-control <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('payment_date')); ?>">
                <?php $__errorArgs = ['payment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="invalid-feedback"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>
            <div class="mb-4">
                <label for="payment_detail_1" class="form-label uppercase">Atas Nama Rekening</label>
                <input id="payment_detail_1" name="payment_detail_1" type="text" class="form-control <?php $__errorArgs = ['payment_detail_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('payment_detail_1')); ?>">
                <?php $__errorArgs = ['payment_detail_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="invalid-feedback"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>
            <div class="mb-4">
                <label for="payment_detail_2" class="form-label uppercase">Nama Bank</label>
                <input id="payment_detail_2" name="payment_detail_2" type="text" class="form-control <?php $__errorArgs = ['payment_detail_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('payment_detail_2')); ?>">
                <?php $__errorArgs = ['payment_detail_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="invalid-feedback"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>
            <div class="mb-4">
                <label for="payment_detail_3" class="form-label uppercase">Catatan (opsional)</label>
                <textarea id="payment_detail_3" name="payment_detail_3" class="form-control <?php $__errorArgs = ['payment_detail_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('payment_detail_3')); ?></textarea>
                <?php $__errorArgs = ['payment_detail_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="invalid-feedback"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
            </div>
            <button class="btn btn-accent w-full mb-2">Konfirmasi Donasi</button>
        </form>
    <?php elseif($donation->payment_status == 2): ?>
        <p class="text-center font-semibold text-green-500 mb-5">Donasi anda sedang diverifikasi mohon tunggu</p>
    <?php endif; ?>
    <a href="<?php echo e(route('campaigns.index')); ?>" class="btn btn-light w-full">Kembali ke-Beranda</a>
</div>
<!-- select payment end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('prepend-scripts'); ?>

<script>
    var countDownDate = new Date("<?php echo e($donation->expired_at); ?>").getTime();
</script>
<script src="<?php echo e(asset('js/countdown.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.donate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMER\Development\nucare\resources\views/pages/donation/invoice.blade.php ENDPATH**/ ?>