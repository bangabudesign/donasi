<!-- Primary Meta Tags -->
<title><?php echo e($meta_title ?? config('app.name')); ?></title>
<meta name="title" content="<?php echo e($meta_title ?? config('app.name')); ?>">
<meta name="description" content="<?php echo e($meta_description ?? config('app.description')); ?>">

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website">
<meta property="og:url" content="<?php echo e(url()->current()); ?>">
<meta property="og:title" content="<?php echo e($meta_title ?? config('app.name')); ?>">
<meta property="og:description" content="<?php echo e($meta_description ?? config('app.description')); ?>">
<meta property="og:image" content="<?php echo e($meta_image ?? ''); ?>">

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image">
<meta property="twitter:url" content="<?php echo e(url()->current()); ?>">
<meta property="twitter:title" content="<?php echo e($meta_title ?? config('app.name')); ?>">
<meta property="twitter:description" content="<?php echo e($meta_description ?? config('app.description')); ?>">
<meta property="twitter:image" content="<?php echo e($meta_image ?? ''); ?>"><?php /**PATH D:\WEB PROGRAMER\Development\nucare\resources\views/shared/meta_tag.blade.php ENDPATH**/ ?>