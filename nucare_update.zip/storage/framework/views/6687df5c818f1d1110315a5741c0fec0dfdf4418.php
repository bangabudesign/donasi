

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex justify-between">
    <div class="left">
        <h2 class="text-3xl font-bold leading-tight"><?php echo e($title); ?></h2>
        <p class="mt-0 text-gray-600"><?php echo e($subtitle); ?></p>
    </div>
    <div class="mt-auto">
        <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-success">Add New</a>
    </div>
</div>
<?php if(session('successMessage')): ?>
    <div class="alert alert-success">
        <?php echo e(session('successMessage')); ?>

    </div>
<?php endif; ?>
<div class="card card-body">
    <div class="-m-6 overflow-x-auto">
        <table class="table w-full whitespace-no-wrap">
            <thead>
                <tr class="text-left">
                    <th>Profile</th>
                    <th>E-Mail</th>
                    <th>Phone</th>
                    <th>Registered At</th>
                    <th>Type</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="flex items-center">
                            <img class="my-auto h-10 w-10 rounded-full" src="<?php echo e($user->profile_photo); ?>" alt="<?php echo e($user->name); ?>">
                            <div class="ml-2">
                                <p class="leading-tight"><?php echo e($user->name); ?></p>
                            </div>
                        </div>                        
                    </td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->created_at != null ? $user->created_at->diffForHumans() : ''); ?></td>
                    <td>
                        <?php if($user->is_admin): ?>
                        <span class="badge badge-info">Admin</span>
                        <?php else: ?>
                            <span class="badge badge-success">Donatur</span>                            
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>" class="btn-text-info">Edit</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No Data</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMER\Development\nucare\resources\views/admin/user/index.blade.php ENDPATH**/ ?>