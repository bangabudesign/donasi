

<?php $__env->startSection('content'); ?>
<!-- select payment -->
<div class="container max-w-md mx-auto px-4 pt-20 pb-24 min-h-screen bg-white">
    <h4 class="font-semibold text-center pb-5">Pilih Metode Pembayaran</h4>
    <div class="payment-method">
        <?php $__empty_1 = true; $__currentLoopData = $methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="payment-option" onclick="selectMethod(event)" 
            data-id="<?php echo e($method->id); ?>" 
            data-name="<?php echo e($method->name); ?>" 
            data-shortname="<?php echo e($method->short_name); ?>"
            data-imageurl="<?php echo e($method->image_url); ?>">
            <div class="flex items-center">
                <div class="rounded overflow-hidden">
                    <img src="<?php echo e($method->image_url); ?>" alt="<?php echo e($method->short_name); ?>">
                </div>
                <p class="ml-3"><?php echo e($method->name); ?></p>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            
        <?php endif; ?>
    </div>
</div>
<!-- select payment end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('prepend-scripts'); ?>

<script>
    const contributeUrl = "<?php echo e(route('donate.contribute', $campaign->slug)); ?>";
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.donate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMER\Development\nucare\resources\views/pages/donate/payment.blade.php ENDPATH**/ ?>