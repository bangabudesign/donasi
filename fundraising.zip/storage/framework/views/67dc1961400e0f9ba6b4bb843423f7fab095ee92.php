

<?php $__env->startSection('content'); ?>
<!-- select amount -->
<form action="<?php echo e(route('donation.store', $campaign->slug)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input id="paymentMethodId" type="hidden" name="payment_method_id">
    <div class="container max-w-md mx-auto px-4 pt-20 pb-24 min-h-screen bg-white">
        <div class="mb-4">
            <label for="inputAmount" class="form-label">ISI NOMINAL DONASI</label>
            <div class="relative">
                <span class="text-xl font-bold text-gray-700 absolute top-0 py-2 px-3">Rp</span>
                <input id="inputAmount" type="number" placeholder="0" name="amount" class="block form-control mt-3 text-right text-xl font-bold <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('amount')); ?>">
            </div>
            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
        <div class="mb-4">
            <div id="methodSelected" class="payment-method">
                <div class="payment-option">
                    <div class="flex items-center">
                        <p>Metode Pembayaran</p>
                    </div>
                    <a href="#" class="btn-sm btn-success" onclick="gotoPayment(event)">Ganti</a>
                </div>
            </div>
            <?php $__errorArgs = ['payment_method_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <?php if(auth()->guard()->guest()): ?>
        <p class="text-center text-sm mb-4"><a class="btn-link" href="<?php echo e(route('login')); ?>">Masuk</a> atau isi data dibawah ini</p>
        <div class="mb-4">
            <label for="name" class="form-label">NAMA LENGKAP</label>
            <input id="name" name="name" type="text" placeholder="Fulan bin Fulan" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
        <div class="mb-5">
            <label for="phone" class="form-label">NOMOR HP</label>
            <input id="phone" name="phone" type="number" placeholder="0812xxx" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('phone')); ?>">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
        <?php endif; ?>
        <div class="mb-5 flex items-center justify-between">
            <p class="text-sm font-semibold tracking-wide text-gray-700 pr-2">Sembunyikan nama saya (Hamba Allah)</p>
            <div class="toggle">
                <input type="checkbox" name="is_anonim" id="toggle" value="1" class="toggle-checkbox"/>
                <label for="toggle" class="toggle-label"></label>
            </div>
        </div>    
        <div class="mb-4">
            <label for="comment" class="form-label">TULIS DO'A DAN DUKUNGAN (opsional)</label>
            <textarea id="comment" name="comment" placeholder="Beri do'a dan dukunganmu disini" rows="4" class="form-control <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('comment')); ?></textarea>
            <?php $__errorArgs = ['comment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="invalid-feedback"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
        </div>
    </div>
    <div class="fixed bottom-0 left-0 right-0 w-full bg-gray-100">
        <div class="container max-w-md mx-auto p-4">
            <button class="btn btn-accent block w-full">Lanjutkan Pembayaran</button>
        </div>
    </div>
</form>
<!-- select amount end -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('prepend-scripts'); ?>

<script>
    const paymentUrl = "<?php echo e(route('donation.payment', $campaign->slug)); ?>";
    const contributeUrl = "<?php echo e(route('donation.contribute', $campaign->slug)); ?>";
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.donate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMER\Development\nucare\resources\views/pages/donation/contribute.blade.php ENDPATH**/ ?>