

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex justify-between">
    <div class="left">
        <h2 class="text-3xl font-bold leading-tight"><?php echo e($title); ?></h2>
        <p class="mt-0 text-gray-600"><?php echo e($subtitle); ?></p>
    </div>
    <div class="mt-auto">
        <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-success">Add New</a>
    </div>
</div>
<?php if(session('successMessage')): ?>
    <div class="alert alert-success">
        <?php echo e(session('successMessage')); ?>

    </div>
<?php endif; ?>
<div class="bg-white p-6 rounded-md shadow overflow-hidden">
    <div class="-m-6 overflow-x-auto">
        <table class="table w-full whitespace-no-wrap">
            <thead>
                <tr class="text-left">
                    <th>Image</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="w-20">
                            <img src="<?php echo e($post->featured_image ? url('/',$post->featured_image) : 'http://placehold.it/400X225'); ?>" alt="fatured_image" class="w-full rounded cursor-pointer hover:shadow">
                        </div>
                    </td>
                    <td><?php echo e($post->title); ?></td>
                    <td><?php echo e($post->user->name); ?></td>
                    <td><?php echo e($post->status); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>" class="btn-text-info">Edit</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5">No Data</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMER\Development\nucare\resources\views/admin/post/index.blade.php ENDPATH**/ ?>