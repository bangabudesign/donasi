

<?php $__env->startSection('content'); ?>
<div class="mb-4 flex justify-between">
    <div class="left">
        <h2 class="text-3xl font-bold leading-tight"><?php echo e($title); ?></h2>
        <p class="mt-0 text-gray-600"><?php echo e($subtitle); ?></p>
    </div>
    <div class="mt-auto">
        <a href="<?php echo e(route('admin.donations.create')); ?>" class="btn btn-success">Add New</a>
    </div>
</div>
<?php if(session('successMessage')): ?>
    <div class="alert alert-success">
        <?php echo e(session('successMessage')); ?>

    </div>
<?php endif; ?>
<div class="bg-white p-6 rounded-md shadow overflow-hidden">
    <div class="-m-6 overflow-x-auto">
        <table class="table w-full whitespace-no-wrap">
            <thead>
                <tr class="text-left">
                    <th>INVOICE</th>
                    <th>Donasi</th>
                    <th>Amount</th>
                    <th>Created at</th>
                    <th>Status</th>
                    <th>Payment</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><a href="<?php echo e(route('donation.invoice', $donation->invoice)); ?>" target="BLANK" class="btn-link"><?php echo e($donation->invoice); ?></a></td>
                    <td>
                        <div class="flex items-center">
                            <img class="my-auto h-10 w-10 rounded-full" src="<?php echo e($donation->display_profile); ?>" alt="Avatar">
                            <div class="ml-2">
                                <p class="leading-tight"><?php echo e($donation->display_name); ?></p>
                                <p class="leading-tight text-gray-500"><?php echo e($donation->campaign->code); ?></p>
                            </div>
                        </div>                        
                    </td>
                    <td>Rp<?php echo e($donation->amount_formatted); ?></td>
                    <td><?php echo e($donation->created_at_formatted); ?></td>
                    <td><?php echo $donation->status_formatted; ?></td>
                    <td><?php echo $donation->payment_status_formatted; ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.donations.edit', $donation->id)); ?>" class="btn-text-info">Edit</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6">No Data</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB PROGRAMER\Development\nucare\resources\views/admin/donation/index.blade.php ENDPATH**/ ?>